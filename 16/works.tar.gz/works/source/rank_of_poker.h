
#include "msg_to_bit.h"

int no_unique(int poker[5]);
int rank_of_poker(int poker[]);

 